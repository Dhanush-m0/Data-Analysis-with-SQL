-- =====================================================================
-- PROJECT : Student Performance Analytics using SQL
-- DOMAIN  : SQL Data Analysis Internship (Maincrafts Technology)
-- COVERS  : Task 1-5  (tables, joins, group by/having, subqueries,
--           CTEs, window functions, views)
-- ENGINE  : Works on MySQL 8+, PostgreSQL, SQLite 3.25+
-- =====================================================================

-- ---------------------------------------------------------------------
-- PART A : DATABASE SETUP
-- ---------------------------------------------------------------------
DROP VIEW  IF EXISTS vw_course_summary;
DROP VIEW  IF EXISTS vw_student_summary;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS students;

CREATE TABLE students (
    id      INT PRIMARY KEY,
    name    VARCHAR(50) NOT NULL,
    gender  CHAR(1)     NOT NULL,      -- 'M' or 'F'
    age     INT
);

CREATE TABLE courses (
    id    INT PRIMARY KEY,
    name  VARCHAR(50) NOT NULL
);

CREATE TABLE enrollments (
    student_id  INT NOT NULL,
    course_id   INT NOT NULL,
    grade       INT NOT NULL,          -- marks out of 100
    semester    VARCHAR(10) NOT NULL,  -- 'Semester 1' / 'Semester 2'
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id)  REFERENCES courses(id)
);

INSERT INTO students (id, name, gender, age) VALUES
(1,  'Aarav',   'M', 20),
(2,  'Priya',   'F', 19),
(3,  'Rahul',   'M', 21),
(4,  'Sneha',   'F', 20),
(5,  'Kiran',   'M', 22),
(6,  'Ananya',  'F', 19),
(7,  'Vikram',  'M', 21),
(8,  'Divya',   'F', 20),
(9,  'Rohit',   'M', 22),
(10, 'Meena',   'F', 21),
(11, 'Arjun',   'M', 20),
(12, 'Lakshmi', 'F', 19);

INSERT INTO courses (id, name) VALUES
(1, 'SQL Fundamentals'),
(2, 'Data Analytics'),
(3, 'Statistics'),
(4, 'Python Programming'),
(5, 'Database Systems');

INSERT INTO enrollments (student_id, course_id, grade, semester) VALUES
-- Aarav (4 courses)
(1, 1, 72, 'Semester 1'), (1, 2, 65, 'Semester 1'), (1, 3, 58, 'Semester 2'), (1, 4, 70, 'Semester 2'),
-- Priya (4 courses)
(2, 1, 91, 'Semester 1'), (2, 2, 88, 'Semester 1'), (2, 3, 94, 'Semester 2'), (2, 5, 90, 'Semester 2'),
-- Rahul (3 courses)
(3, 1, 45, 'Semester 1'), (3, 3, 38, 'Semester 1'), (3, 4, 52, 'Semester 2'),
-- Sneha (4 courses)
(4, 2, 77, 'Semester 1'), (4, 3, 81, 'Semester 1'), (4, 4, 85, 'Semester 2'), (4, 5, 89, 'Semester 2'),
-- Kiran (2 courses)
(5, 1, 35, 'Semester 1'), (5, 5, 42, 'Semester 2'),
-- Ananya (4 courses)
(6, 1, 84, 'Semester 1'), (6, 2, 79, 'Semester 1'), (6, 4, 92, 'Semester 2'), (6, 5, 87, 'Semester 2'),
-- Vikram (3 courses)
(7, 2, 55, 'Semester 1'), (7, 3, 48, 'Semester 1'), (7, 5, 61, 'Semester 2'),
-- Divya (4 courses)
(8, 1, 68, 'Semester 1'), (8, 2, 74, 'Semester 1'), (8, 3, 71, 'Semester 2'), (8, 4, 80, 'Semester 2'),
-- Rohit (2 courses)
(9, 3, 30, 'Semester 1'), (9, 4, 44, 'Semester 2'),
-- Meena (3 courses)
(10, 1, 62, 'Semester 1'), (10, 2, 59, 'Semester 1'), (10, 5, 73, 'Semester 2'),
-- Arjun (4 courses)
(11, 2, 90, 'Semester 1'), (11, 3, 83, 'Semester 1'), (11, 4, 78, 'Semester 2'), (11, 5, 82, 'Semester 2'),
-- Lakshmi (3 courses)
(12, 1, 51, 'Semester 1'), (12, 4, 46, 'Semester 2'), (12, 5, 57, 'Semester 2');


-- ---------------------------------------------------------------------
-- PART B : ANALYTICAL REPORTS
-- ---------------------------------------------------------------------

-- REPORT 1 | Students enrolled in each course (Task 2 - JOIN)
SELECT c.name AS course, COUNT(e.student_id) AS students_enrolled
FROM courses c
JOIN enrollments e ON c.id = e.course_id
GROUP BY c.id, c.name
ORDER BY students_enrolled DESC, course;

-- REPORT 2 | Average Grade by Gender (Task 4.1 - JOIN + GROUP BY)
SELECT s.gender,
       COUNT(*)               AS total_enrollments,
       ROUND(AVG(e.grade), 2) AS avg_grade
FROM students s
JOIN enrollments e ON s.id = e.student_id
GROUP BY s.gender;

-- REPORT 3 | Pass Rate per Course, pass = grade >= 40 (Task 4.2)
SELECT c.name AS course,
       COUNT(*)                                            AS total_students,
       SUM(CASE WHEN e.grade >= 40 THEN 1 ELSE 0 END)      AS passed,
       ROUND(SUM(CASE WHEN e.grade >= 40 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pass_rate_pct
FROM enrollments e
JOIN courses c ON e.course_id = c.id
GROUP BY c.id, c.name
ORDER BY pass_rate_pct DESC, course;

-- REPORT 4 | Top 3 Students Overall by average grade (Task 4.3)
SELECT s.name AS student, ROUND(AVG(e.grade), 2) AS avg_grade
FROM enrollments e
JOIN students s ON e.student_id = s.id
GROUP BY s.id, s.name
ORDER BY avg_grade DESC
LIMIT 3;

-- REPORT 5 | Students enrolled in MORE THAN 2 courses (Task 4.4 - HAVING)
SELECT s.name AS student, COUNT(e.course_id) AS courses_enrolled
FROM enrollments e
JOIN students s ON e.student_id = s.id
GROUP BY s.id, s.name
HAVING COUNT(e.course_id) > 2
ORDER BY courses_enrolled DESC, student;

-- REPORT 6 | Improvement Report: Semester 2 avg vs Semester 1 avg (Task 4.5 - CTE)
WITH sem AS (
    SELECT student_id,
           AVG(CASE WHEN semester = 'Semester 1' THEN grade END) AS sem1_avg,
           AVG(CASE WHEN semester = 'Semester 2' THEN grade END) AS sem2_avg
    FROM enrollments
    GROUP BY student_id
)
SELECT s.name AS student,
       ROUND(sem.sem1_avg, 1)               AS sem1_avg,
       ROUND(sem.sem2_avg, 1)               AS sem2_avg,
       ROUND(sem.sem2_avg - sem.sem1_avg, 1) AS improvement
FROM sem
JOIN students s ON s.id = sem.student_id
WHERE sem.sem2_avg > sem.sem1_avg
ORDER BY improvement DESC;

-- REPORT 7 | Students who FAILED at least one course, grade < 40 (Task 2 / Subquery)
SELECT s.name AS student, c.name AS course, e.grade
FROM enrollments e
JOIN students s ON s.id = e.student_id
JOIN courses  c ON c.id = e.course_id
WHERE e.student_id IN (SELECT student_id FROM enrollments WHERE grade < 40)
  AND e.grade < 40
ORDER BY e.grade;

-- REPORT 8 | Top 3 Students per Course using RANK() (Task 5 - Window Function)
WITH ranked AS (
    SELECT c.name AS course, s.name AS student, e.grade,
           RANK() OVER (PARTITION BY e.course_id ORDER BY e.grade DESC) AS rnk
    FROM enrollments e
    JOIN students s ON s.id = e.student_id
    JOIN courses  c ON c.id = e.course_id
)
SELECT course, rnk AS rank_in_course, student, grade
FROM ranked
WHERE rnk <= 3
ORDER BY course, rnk;

-- REPORT 9 | Performance Quartiles of students using NTILE(4) (Task 5)
WITH student_avg AS (
    SELECT s.name AS student, AVG(e.grade) AS avg_grade
    FROM enrollments e
    JOIN students s ON s.id = e.student_id
    GROUP BY s.id, s.name
)
SELECT student,
       ROUND(avg_grade, 1) AS avg_grade,
       NTILE(4) OVER (ORDER BY avg_grade DESC) AS quartile   -- 1 = top 25%
FROM student_avg
ORDER BY avg_grade DESC;

-- REPORT 10 | Reusable VIEW: course summary for dashboards (Task 5 - VIEW)
CREATE VIEW vw_course_summary AS
SELECT c.name AS course,
       COUNT(*)                AS students,
       ROUND(AVG(e.grade), 1)  AS avg_grade,
       MAX(e.grade)            AS highest,
       MIN(e.grade)            AS lowest,
       ROUND(SUM(CASE WHEN e.grade >= 40 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pass_rate_pct
FROM enrollments e
JOIN courses c ON c.id = e.course_id
GROUP BY c.id, c.name;

SELECT * FROM vw_course_summary ORDER BY avg_grade DESC;
