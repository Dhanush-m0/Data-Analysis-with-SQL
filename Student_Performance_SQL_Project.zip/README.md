# Student Performance Analytics using SQL

**SQL Data Analysis Internship – Maincrafts Technology (Tasks 1–5)**

## Project summary
A small student database (12 students, 5 courses, 40 enrollments) analysed with SQL.
The project answers management-style questions using JOINs, GROUP BY, HAVING, CASE,
subqueries, CTEs, window functions (RANK, NTILE) and a reusable VIEW.

**Tables:** `students(id, name, gender, age)`, `courses(id, name)`, `enrollments(student_id, course_id, grade, semester)`  
**Pass mark:** grade ≥ 40  
**Script:** `student_performance_project.sql` (works on MySQL 8+, PostgreSQL, SQLite 3.25+)

## Reports explained in plain English
| # | Report | Result |
|---|--------|--------|
| 1 | Students per course | Every course has 8 enrolled students. |
| 2 | Average grade by gender | Female students average 76.27, male students 58.22. |
| 3 | Pass rate per course | Data Analytics, Database Systems and Python Programming: 100% passed. SQL Fundamentals: 87.5%. Statistics: 75%. |
| 4 | Top 3 students overall | Priya (90.75), Ananya (85.5), Arjun (83.25). |
| 5 | Students in more than 2 courses | 10 of 12 students; 6 of them take 4 courses. |
| 6 | Improvement report | 10 of 12 students scored higher in Semester 2. Biggest gains: Rohit (+14), Meena (+12.5), Rahul (+10.5). |
| 7 | Failed students | Rohit (Statistics, 30), Kiran (SQL Fundamentals, 35), Rahul (Statistics, 38). |
| 8 | Top 3 per course (RANK) | Priya is 1st in SQL Fundamentals, Statistics and Database Systems. Arjun is 1st in Data Analytics, Ananya in Python. |
| 9 | Performance quartiles (NTILE) | Top quartile: Priya, Ananya, Arjun. Bottom quartile (at risk): Rahul, Kiran, Rohit. |
| 10 | View `vw_course_summary` | Data Analytics has the highest average (73.4); Statistics the lowest (62.9). |

## Key insights
- Statistics is the hardest course (75% pass rate, lowest average).
- Three students failed a course and should get academic support.
- Overall performance improves from Semester 1 to Semester 2.

## Files
- `student_performance_project.sql` – full script (setup, data, 10 reports, view)
- `output_screenshots/` – result table for every report + 3 charts
- `Student_Performance_SQL_Project.pptx` – ready-made project slides
